"""Build data/port_review.json from Member 1's T02 / T03 results (member1_review/results).

The file is *documentation + triage flags only*.  It never changes a supplied
project ID, coordinate or benchmark value.  Re-run it when Member 1 re-issues
their results:   python scripts/build_port_review.py
"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "member1_review", "results")

# Proposed corrections documented by Member 1 (README, T02 table).  NOT applied.
IDENTITY_REVIEW = {
    "GIIBZ": {
        "status": "proposed_code_mapping",
        "proposed_un_locode": "GIGIB",
        "note": ("Supplied code GIIBZ has no UN/LOCODE record; GIGIB is the Gibraltar record. "
                 "GIIBZ is kept as the project key; GIGIB is a proposed official-code mapping."),
    },
    "CNSHA": {
        "status": "needs_review",
        "proposed_un_locode": None,
        "candidates": ["CNSGH (Shanghai)", "CNSHG (Shanghai Pt)"],
        "note": ("CNSHA is Shanghai Hongqiao International Apt in the UN/LOCODE reference (function "
                 "'---4----', not a maritime port). Intended city/terminal needs review; coordinates "
                 "and code are NOT moved automatically."),
    },
    "PAMIT": {
        "status": "needs_review",
        "proposed_un_locode": None,
        "note": ("Reference name for PAMIT is Manzanillo, while the workbook says Colon (aliases "
                 "Cristobal/Colon). Regional versus terminal scope must be reconciled."),
    },
}


def main():
    t2 = json.load(open(os.path.join(RES, "t02.json")))
    t3 = json.load(open(os.path.join(RES, "t03.json")))
    snaps = {p["port_id"]: p for p in t3["ports"]}
    ports = {}
    for p in t2["ports"]:
        pid = p["port_id"]
        s = snaps[pid]
        ports[pid] = {
            "identifier_in_unlocode_reference": p["identifier_match"],
            "identity_review": IDENTITY_REVIEW.get(pid),
            "approach_snap_nm": s["origin_snap_nm"],
            "approach_snap_review": s["status"] == "REVIEW_SNAP",
            "approach_approved": bool(s["approach_approved"]),
        }
    out = {
        "source": "Member 1 review of 11 November 2026 (T02, T03)",
        "workbook_sha256_note": "workbook is byte-identical to data/voyage_planner_datasets.xlsx",
        "snap_review_trigger_nm": t3["review_snap_nm"],
        "snap_review_trigger_basis": t3["review_threshold_basis"],
        "searoute_version": t3["searoute_version"],
        "limitations": t3["limitations"],
        "t02_status": {"identifiers_matched": t2["matched_identifiers"] if "matched_identifiers" in t2 else None,
                       "needs_review": t2["ports_requiring_review"]},
        "ports": ports,
    }
    path = os.path.join(ROOT, "data", "port_review.json")
    with open(path, "w") as f:
        json.dump(out, f, indent=2)
    flagged = [k for k, v in ports.items() if v["approach_snap_review"]]
    print("wrote", path, "| snap-review ports:", flagged, "| identity review:", list(IDENTITY_REVIEW))


if __name__ == "__main__":
    main()
