# Maritime-Voyage-Planner
Maritime Voyage Planner - SDD Project 6

Maritime distance and route-planning service: port-to-port, vessel-position-to-port and
multi-leg voyages, with required/excluded canals, straits and capes. Academic prototype
built on [searoute-py](https://github.com/genthalili/searoute-py); **not for navigation**.

## Repository layout
```
voyage_planner/   routing engine (Member 2) + HTTP API voyage_planner/api.py (Member 3)
tests/            test_engine.py (engine) and test_api.py (API)
scripts/          run_benchmarks.py, demo.py, t16_network_probe.py
docs/             CODE_WALKTHROUGH.md, HANDOFF_NOTES.md, T16 findings, T32 methodology
results/          benchmark and T16 evidence
data/             voyage_planner_datasets.xlsx (reference data used by engine and UI)
app.py            Streamlit user interface (Member 4)
archive/          original submissions (zips) and the 6 Oct workbook
```

## Setup (once, from the repository root)
Needs Python 3.9+. On macOS/Linux use `python3`; on Windows use `py`.
```bash
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Run
```bash
uvicorn voyage_planner.api:app --reload   # API on http://127.0.0.1:8000 (docs at /docs)
streamlit run app.py                      # user interface
python scripts/run_benchmarks.py          # benchmark table (10/10 expected)
python -m pytest -q                       # engine + API tests
```
Use a different workbook by setting `VOYAGE_PLANNER_DATA=/path/file.xlsx`.

## API
| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | Service status and `calculation_version` |
| GET | `/ports` | Ports (lookup by `port_id`, UN/LOCODE, name or alias) |
| GET | `/passages` | Passage IDs for `required_passage` / `excluded_passage` |
| GET | `/positions` | Synthetic vessel positions (`origin_position_id`) |
| POST | `/route` | One route: port or position to port, optional passages |
| POST | `/voyage` | Multi-leg voyage: distance per leg and total |

Example:
```bash
curl -X POST http://127.0.0.1:8000/route -H "Content-Type: application/json" \
  -d '{"origin_port_id": "USHOU", "destination_port_id": "CLTOQ", "required_passage": "PANAMA"}'
```
Errors use `{"status": "error", "error_code": ..., "message": ..., "warnings": [...]}` with HTTP
404 for `PORT_NOT_FOUND`, 422 for `ROUTE_NOT_FOUND` and 400 for every other code
(`MISSING_ORIGIN`, `MISSING_DESTINATION`, `INVALID_COORDINATES`, `INVALID_PASSAGE`, `INVALID_REQUEST`).
Full request/response fields: `docs/HANDOFF_NOTES.md` and the interactive `/docs` page.
