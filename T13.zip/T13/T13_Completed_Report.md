# T13 — Independent maritime distance references and local engine comparison

**Project:** Voyage Planner — Maritime Distance and Voyage Calculation Service  
**Task owner:** Member 1  
**NGA reference research:** 11 November 2026  
**Member 2 engine verification and comparison:** 12 November 2026

## 1. Findings

T13's reference research and comparison are complete for all ten supplied cases. Two cases have direct published port-pair distances, six have qualified constructions from published distances, one has no matching Cape Horn reference in the checked publication, and one has a synthetic origin to which a port-distance table does not apply.

Member 2's local engine was rerun, and all ten saved distances reproduced exactly at the service's reported precision of 0.1 nautical mile (nm). The nine distance-accuracy cases are within the supplied Excel tolerances, with absolute errors no greater than 0.4 nm. BM_009 was treated separately as a functional case: an explicit coordinate-origin request passed the local input and response checks. It is not an independent accuracy benchmark.

For the eight numeric NGA comparisons, differences range from -56.7 nm to +224.8 nm. These are descriptive comparisons, not NGA pass/fail outcomes. Six references are assembled from published legs with stated qualifications; they are not exact reproductions of the service's coordinates or geometry. No independent NGA acceptance tolerance was specified or invented.

This completes T13 research and the local comparison. It does not complete the later independent geometry, deployed API or final-system validation tasks.

## 2. Inputs and method

### Project data and local calculation

The benchmark targets, tolerances, required passages, exclusions and itinerary stops were read from the supplied `voyage_planner_datasets.xlsx`. The workbook in Member 2's `data/` folder is byte-identical to Member 1's supplied workbook. Source data, coordinates and expected distances were not modified.

The verified local configuration was:

| Item | Recorded setting |
|---|---|
| Student service | `VoyagePlanner`, calculation version 0.1.0 |
| Routing library | searoute-py 1.6.0 |
| Reported units | Nautical miles |
| Network | Bundled network: 9,708 nodes and 15,970 edges |
| Default exclusion | `northwest` |
| Input endpoints appended | `append_orig_dest=False` |
| Routing input points | Supplied port approach points and passage references |
| Endpoint access distances | Snapped input-to-network distances excluded from the route total |
| Verification scope | Local Python calls; not hosted HTTP endpoints |

The comparison uses the actual results returned by the local service. The baseline values are used only as validation targets; they are not substituted for calculated values. The full requests, responses, route geometry, routing points, warnings and configuration are saved in `evidence/local_engine_verification.json`.

### Independent reference

The independent source is **Publication 151, Distances Between Ports, 11th edition (2001)**. The historical copy's title page names the National Imagery and Mapping Agency (NIMA), NGA's predecessor. Its Preface specifies nautical miles, central port reference positions, and a method of adding published distances through junction points. It also warns that some distances are directional because routes can differ with currents or weather.

NGA's download endpoints were unavailable during the reference research, so the publication was retrieved from the Marcon mirror. The exact historical PDFs and source hashes are included. The mirror index advertises corrections through Notice to Mariners 14/2004; this work does not independently certify every correction in that copy or represent the edition as a current operational routing service.

The supplied Excel values remain the required targets. Since those targets were generated with searoute-py 1.6.0, close agreement demonstrates consistency with that model-derived baseline, not independent accuracy.

### Calculations

- Excel absolute error = absolute value of **engine distance minus supplied Excel distance**.
- Excel distance condition = absolute error no greater than the case's supplied tolerance.
- NGA signed difference = **engine distance minus independent reference**. Negative means the engine route is shorter.
- NGA signed percentage difference = signed difference divided by the independent reference, multiplied by 100.

Distance-only outcomes do not establish that a required passage is geographically satisfied, an excluded passage is absent, or the API meets its full contract. Those are separate checks.

## 3. Comparison with supplied Excel targets

All figures are nautical miles. Values are the service's rounded outputs; differences are shown to 0.1 nm.

| Case | Route | Engine | Excel target | Absolute error | Tolerance | Local distance outcome |
|---|---|---:|---:|---:|---:|---|
| BM_001 | Singapore-Hong Kong | 1,438.8 | 1,439 | 0.2 | 100 | Within tolerance |
| BM_002 | Rotterdam-Hamburg | 297.7 | 298 | 0.3 | 100 | Within tolerance |
| BM_003 | Singapore-Rotterdam | 8,368.2 | 8,368 | 0.2 | 250 | Within tolerance |
| BM_004 | Houston-Rotterdam | 5,041.2 | 5,041 | 0.2 | 250 | Within tolerance |
| BM_005 | Houston-Tocopilla via Panama | 3,594.3 | 3,594 | 0.3 | 250 | Within tolerance |
| BM_006 | Houston-Tocopilla via Cape Horn; Panama excluded | 9,972.6 | 9,973 | 0.4 | 250 | Within tolerance |
| BM_007 | Rotterdam-Durban via Suez | 7,943.3 | 7,943 | 0.3 | 250 | Within tolerance |
| BM_008 | Rotterdam-Durban via Cape of Good Hope | 7,178.8 | 7,179 | 0.2 | 250 | Within tolerance |
| BM_009 | Synthetic POS_001-Singapore | 720.8 | 721 | 0.2 | 150 | Functional case; figures retained for context |
| BM_010 | Singapore-Hong Kong-Colombo-Durban | 8,271.0 | 8,271 | 0.0 | 300 | Within tolerance |

The service reports PANAMA for BM_005, CAPE_HORN for BM_006, GIBRALTAR/SUEZ for BM_007, and CAPE_GOOD_HOPE for BM_008. Those labels are engine output, not independent proof of passage compliance. BM_006's request includes the updated PANAMA exclusion. The full requests and geometry remain available for Member 3's independent tests.

## 4. Comparison with independent published references

| Case | Engine (nm) | NGA reference (nm) | Engine minus NGA (nm) | Signed difference | Reference basis |
|---|---:|---:|---:|---:|---|
| BM_001 | 1,438.8 | 1,454 | -15.2 | -1.05% | Direct entry, p.104 |
| BM_002 | 297.7 | 307 | -9.3 | -3.03% | Direct entry, p.94 |
| BM_003 | 8,368.2 | 8,340 | +28.2 | +0.34% | Published junction sum via Suez |
| BM_004 | 5,041.2 | 5,058 | -16.8 | -0.33% | Published adjustment and legs; one reciprocal assumption |
| BM_005 | 3,594.3 | 3,651 | -56.7 | -1.55% | Published adjustment and Panama-junction legs |
| BM_006 | 9,972.6 | Not available | Not applicable | Not applicable | No matching constrained reference found |
| BM_007 | 7,943.3 | 7,872 | +71.3 | +0.91% | Published junction sum via Suez |
| BM_008 | 7,178.8 | 6,954 | +224.8 | +3.23% | Published junction sum via Cape of Good Hope |
| BM_009 | 720.8 | Not applicable | Not applicable | Not applicable | Synthetic origin |
| BM_010 | 8,271.0 | 8,104 | +167.0 | +2.06% | Qualified published-leg itinerary sum |

### Published constructions and locators

Printed page numbers below match the one-based PDF pages in `sources/Worldports.pdf`. Each component is recorded individually in the workbook's `NGA Evidence` sheet.

| Case | Published construction (nm) | Pages | Qualification |
|---|---|---|---|
| BM_003 | Singapore-Port Said 5,035 + Port Said-Gibraltar 1,943 + Gibraltar-Ile d'Ouessant 918 + Ile-Rotterdam 444 = **8,340** | 103, 85, 108, 45 | Selected Suez corridor; Excel does not mandate a passage. Engine reports Suez and Gibraltar, but exact junction/geometry equivalence is not established. |
| BM_004 | Houston adjustment 47 + Galveston-Florida 698 + Florida-Bishop Rock 3,859 + Bishop Rock-Rotterdam 454 = **5,058** | 44, 36, 14 | The Atlantic leg uses the reverse of the published Bishop Rock-Florida direction. The Preface says most, but not all, distances are reciprocal. |
| BM_005 | Houston adjustment 47 + Galveston-Panama 1,536 + Panama-Tocopilla 2,068 = **3,651** | 44, 36, 77; Panama entry starts p.76 | The published Panama junction is on the Pacific side. Do not add another canal distance. Junction coordinates differ from the workbook waypoint. |
| BM_007 | Rotterdam-Ile 444 + Ile-Gibraltar 918 + Gibraltar-Port Said 1,943 + Port Said-Durban 4,567 = **7,872** | 94, 44, 108, 85 | Supports the Suez corridor, but uses Port Said and published junctions rather than the exact forced SUEZ waypoint. |
| BM_008 | Rotterdam-Ile 444 + Ile-Cape 5,746 + Cape-Durban 764 = **6,954** | 94, 44, 21 | Published Cape junction differs from the workbook waypoint and its snapped network point. |
| BM_010 | Singapore-Hong Kong 1,454 + Hong Kong-Singapore 1,454 + Singapore-Colombo 1,581 + Colombo-Durban 3,615 = **8,104** | 104, 43, 104, 26 | Singapore is an added junction inside the second reference leg. The final published leg specifies east of Madagascar. |

The Houston 47 nm item is a published instruction to add to Galveston distances; it is not a separately tabulated Houston-Galveston sailing leg. The N04 evidence value used for Gibraltar-Port Said is explicitly listed in that direction on p.108, as well as reciprocally on p.85.

## 5. Interpretation and discrepancies

### Rotterdam-Hamburg

The local service returns **297.7 nm**, 0.3 nm below the supplied target and **9.3 nm below the published 307 nm entry**. The NGA and Excel reference values themselves differ by 9 nm.

The publication's Rotterdam position is 51 degrees 54 minutes N, 4 degrees 28 minutes E; the workbook uses 51.95 N, 4.14 E. The local service then snaps Rotterdam by 0.8 nm and Hamburg by 1.6 nm, excluding those access distances from the route total. Different reference positions and route conventions provide plausible reasons for disagreement, but their individual effects have not been isolated. No coordinates or routing parameters were changed to force either reference value.

The earlier direct-library result, 297.672 nm, rounds to the service's 297.7 nm. The report uses the service's reported precision consistently.

### Cape of Good Hope alternative

BM_008 has the largest absolute NGA difference: **+224.8 nm (+3.23%)**. The published Cape junction is 34 degrees 22 minutes S, 18 degrees 23 minutes E. The workbook waypoint is -34.36, 18.47, and the service reports that it snaps **29.9 nm** to a network point at approximately -33.862433, 18.428192.

The published construction and the service's forced-waypoint route therefore use different geometries. The forced network point and other routing conventions may contribute to the difference, but no causal allocation of the 224.8 nm has been demonstrated. This case remains a qualified comparison and a specific item for independent passage-geometry review. Matching the Excel distance does not resolve that geographic question.

### Multi-leg itinerary

The service and reference totals reconcile as follows:

| Voyage leg | Local engine (nm) | Published reference (nm) | Difference (nm) |
|---|---:|---:|---:|
| Singapore-Hong Kong | 1,438.8 | 1,454 | -15.2 |
| Hong Kong-Colombo | 3,037.9 | 3,035 via Singapore junction | +2.9 |
| Colombo-Durban | 3,794.3 | 3,615 east of Madagascar | +179.3 |
| **Total** | **8,271.0** | **8,104** | **+167.0** |

Most of the total difference is in Colombo-Durban. This research has not independently established that the engine follows the same Madagascar-side and reference-point conventions as the published leg. The requested Colombo-Durban direction is used: the reverse Durban-Colombo entry is separately listed at 3,704 nm on p.31 and is not silently substituted.

An explicit API-spec-style three-leg local request also reproduced the total. The reported leg distances sum to 8,271.0 nm.

### Snapping and omitted access distances

Tocopilla's input-to-network gap is **114.2 nm**, affecting BM_005 and BM_006. BM_009's synthetic origin gap is **124.0 nm**. These distances are excluded from the service's returned totals. The SUEZ reference point also snaps 11.0 nm, and the Cape reference point 29.9 nm.

A numerical match against the model-derived baseline cannot establish navigable access from those supplied points. Adding a straight-line connector would not establish navigability either. Supplied points are preserved for benchmark consistency; any refined approach points should form a separately documented configuration rather than an adjustment to hit target distances.

## 6. Cases without a numeric NGA comparator

### BM_006: Cape Horn

No defensible Houston-Tocopilla construction satisfying the required Cape Horn route was found in the checked edition. The publication contains Tocopilla-Punta Arenas distances and a Cape Horn-labelled distance for a different port pair, but those do not establish this benchmark's constrained route. Punta Arenas/Magellan distances must not be relabelled as Cape Horn distances.

The independent-reference result is therefore **“No matching reference found in the checked edition”**, not a fabricated value or a claim that no reference exists anywhere. The actual local result is 9,972.6 nm against the supplied 9,973 +/-250 nm target. Independent geometry checks must confirm the intended Cape Horn constraint and Panama exclusion.

### BM_009: synthetic position

POS_001 is fictional, so Publication 151 has no equivalent departure-port entry. An explicit request using `origin_coordinates` latitude 10.0, longitude 114.0 and destination SGSIN was submitted to the local handler. Thirteen recorded checks passed, covering success status, required response fields, positive finite distance, preserved origin, correct destination, nonempty geometry, finite coordinates/valid latitudes, nautical-mile units, assumptions, academic warning, calculation version, agreement with the position-ID request and deterministic repeated output.

The result was **720.8 nm**, with the 124.0 nm origin snapping warning retained. This establishes the tested local input/response behaviour, not independent distance accuracy or the behaviour of a hosted HTTP endpoint. Geographic plausibility remains limited by network resolution and the omitted access distance.

## 7. Conclusion and handoff

T13 is complete as a documented independent-reference study and local comparison. The handoff includes all ten cases, eight numerical independent comparators with their qualifications, the Rotterdam-Hamburg investigation, the two justified reference gaps, and a complete calculation/evidence trail.

The local engine is consistent with the supplied distance baseline for the nine accuracy cases. The independent comparisons do not establish navigational accuracy. Material limitations include historical reference definitions, constructed junction routes, one reciprocity assumption, directional differences, network snapping and unresolved geometric equivalence.

Member 3's independent passage/geometry and deployed API checks, T26's broader validation and T35's final validation report remain separate team work. These limits do not require another routing engine or an invented NGA value to finish T13.

## Sources and evidence

- **Benchmark input:** supplied `voyage_planner_datasets.xlsx`, `Benchmark Routes` tab, current updated BM_006 definition; SHA-256 `6e3ca0c922f07820d75b6e261bc05e0bb1193ba746a0fc66b49be487a365cb99`.
- **Engine:** Member 2's `Member2_Routing/voyage_planner/`, rerun 12 November 2026. Calculation version 0.1.0, searoute 1.6.0. Per-file code hashes and full result evidence are recorded in `evidence/local_engine_verification.json`.
- **Publication:** NGA/NIMA, *Publication 151, Distances Between Ports*, 11th edition, 2001. Preface printed p.I (page 4 of `dbpfirst.pdf`); individual distances cited by printed page in the report and workbook.
- **Official catalogue:** https://msi.nga.mil/Publications/DBP
- **Port tables retrieved:** https://www.marcon.com/library/resources/DBP/Worldports.pdf
- **Front matter retrieved:** https://www.marcon.com/library/resources/DBP/dbpfirst.pdf
- **Junction chartlets retrieved:** https://www.marcon.com/library/resources/DBP/dbpfront.pdf
- **Mirror archive:** https://www.marcon.com/library/resources/DBP/pub151.zip
- **NGA-source access date:** 11 November 2026. Exact PDFs and source hashes are in `sources/`.
- **Supporting workbook:** `T13_Completed_Comparisons.xlsx`, with formula-linked comparisons, published evidence ledger and instructions. Original reference distances and source pages are preserved.
