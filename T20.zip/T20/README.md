# Member 1 — T20 handoff

Start with **T20_Comparison_Report.md**. It contains the two alternative-route comparisons, passage settings, distance differences, interpretation, checks and limitations.

| Comparison | Option A | Option B | Difference |
|---|---:|---:|---:|
| Houston–Tocopilla | Panama 3,594.3 nm | Cape Horn 9,972.6 nm; Panama excluded | Cape Horn is 6,378.3 nm longer |
| Rotterdam–Durban | Suez 7,943.3 nm | Cape 7,178.8 nm; Suez excluded | Cape is 764.5 nm shorter in this implementation |

**T20_Verified_Results.json** retains the full calculated responses, including route geometry and warnings. **run_t20.py** reproduces the results using Member 2's existing engine and supplied data.

No source data or original member submissions were modified. This handoff completes the comparison calculations and write-up. Independent geographic checks remain separate; the Cape of Good Hope waypoint's 29.9 nm snap and Tocopilla's 114.2 nm snap must remain visible in the final validation work.
