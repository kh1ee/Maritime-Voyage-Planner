# T20 — Alternative route comparison

**Project:** Voyage Planner — Maritime Distance and Voyage Calculation Service  
**Comparison and write-up:** Member 1  
**Routing and comparison implementation:** Member 2  
**Verified:** 12 November 2026  
**Units:** nautical miles (nm)

## 1. Purpose and scope

T20 compares alternative passage choices for the same origin and destination. The two selected comparisons are:

1. Houston to Tocopilla through the Panama Canal versus through Cape Horn, excluding Panama for the Cape Horn option.
2. Rotterdam to Durban through the Suez Canal versus through the Cape of Good Hope, excluding Suez for the Cape option.

Both comparisons were rerun using Member 2's existing `VoyagePlanner.compare_standard_alternatives()` method. This calls the student-built `compare()` method, which calculates each option through the routing engine. No distances were copied from the Excel targets, and no separate routing engine was built for this task.

The comparison response was checked against the API specification's section 7 fields: `comparison_id`, `options`, `distance_difference_nm` and `warnings`. The supplied API specification does not require a dedicated comparison endpoint. The current interface can also compare alternatives by sending one `/route` request per option.

## 2. Configuration and controls

The following settings were shared across the four options:

| Item | Setting |
|---|---|
| Student calculation version | 0.1.0 |
| Routing library | searoute-py 1.6.0 |
| Workbook | Supplied updated `voyage_planner_datasets.xlsx` |
| Workbook SHA-256 | `6e3ca0c922f07820d75b6e261bc05e0bb1193ba746a0fc66b49be487a365cb99` |
| Network | Bundled network; 9,708 nodes and 15,970 edges |
| Default restriction | Northwest Passage blocked |
| Coordinates | Supplied approach points and passage reference points |
| Endpoint handling | Input points snapped to network nodes; access distances excluded |
| Endpoint append setting | `append_orig_dest=False` |
| Execution scope | Local engine; no hosted API request in this T20 rerun |

The same endpoint coordinates and library configuration were used for each pair. Only the passage constraints differed. Required passage reference points were included in the route chain; excluded canals were blocked using the library's passage tags. The engine routes through snapped network points rather than necessarily through the exact requested coordinates.

## 3. Houston–Tocopilla: Panama versus Cape Horn

| Option | Origin | Destination | Required passage | Excluded passage | Calculated distance (nm) | Engine-reported passages |
|---|---|---|---|---|---:|---|
| Via Panama Canal | USHOU | CLTOQ | PANAMA | None additional | **3,594.3** | PANAMA |
| Via Cape Horn | USHOU | CLTOQ | CAPE_HORN | PANAMA | **9,972.6** | CAPE_HORN |

The default Northwest Passage restriction applies to both options; “None additional” does not remove it.

**Distance difference:** 9,972.6 − 3,594.3 = **6,378.3 nm**.

The Cape Horn option is **177.46% longer than the Panama option**, using the Panama distance as the denominator. Equivalently, the Panama option is 63.96% shorter than the Cape Horn option, using the Cape Horn distance as the denominator. These percentages describe distance only.

### Interpretation

The shorter network route passes through Panama. Requiring Cape Horn while excluding Panama produces a substantially longer route around southern South America. The explicit Panama exclusion is important: the updated BM_006 definition excludes Panama to avoid the earlier ambiguous canal-plus-cape routing behaviour.

The returned comparison labels, arithmetic and independently repeated individual route calls agree. This confirms the tested comparison behaviour, not independent passage geography.

### Qualification

Tocopilla's supplied approach point snaps **114.2 nm** onto the routing network. That access distance is excluded from both returned totals. Cape Horn's required reference point snaps approximately **6.0 nm**. The network results must therefore be reported with their endpoint limitations. Adding a straight-line connector would not establish a navigable approach.

## 4. Rotterdam–Durban: Suez versus Cape of Good Hope

| Option | Origin | Destination | Required passage | Excluded passage | Calculated distance (nm) | Engine-reported passages |
|---|---|---|---|---|---:|---|
| Via Suez Canal | NLRTM | ZADUR | SUEZ | None additional | **7,943.3** | GIBRALTAR, SUEZ |
| Via Cape of Good Hope | NLRTM | ZADUR | CAPE_GOOD_HOPE | SUEZ | **7,178.8** | CAPE_GOOD_HOPE |

**Distance difference:** 7,943.3 − 7,178.8 = **764.5 nm**.

The Cape option is **9.62% shorter than the Suez option**, using the Suez distance as the denominator. Equivalently, Suez is 10.65% longer than the Cape option, using the Cape distance as the denominator.

### Interpretation

For this origin–destination pair, the calculated Cape option is shorter in the selected network. This result does not mean the Cape route is always shorter than Suez for other voyages. It also does not establish the most economical or operationally suitable choice: the comparison measures distance, with the stated routing assumptions.

For this comparison, Suez is explicitly excluded from the Cape option. The supplied BM_008 Excel row does not contain that exclusion; the constrained comparison nevertheless reproduces the BM_008 distance at the reported precision. The additional exclusion is recorded rather than silently treated as an identical request.

### Qualification requiring review

The supplied Cape of Good Hope waypoint (-34.36, 18.47) snaps **29.9 nm** to a network point around (-33.862433, 18.428192). The SUEZ waypoint snaps approximately **11.0 nm**. The comparison's Cape label and a matching benchmark distance do not independently demonstrate that the intended geographic passage is satisfied.

Members 2 and 3 should review the actual Cape geometry. T20 preserves the current implementation and reports the result with that qualification; it does not change coordinates to obtain a preferred number.

## 5. Cross-check against supplied benchmark values

The following is a numerical consistency check using the supplied Excel targets, not an independent distance-accuracy check:

| Case | Option | Calculated (nm) | Excel target (nm) | Engine minus Excel (nm) | Tolerance (nm) | Distance-only outcome |
|---|---|---:|---:|---:|---:|---|
| BM_005 | Panama | 3,594.3 | 3,594 | +0.3 | 250 | Within tolerance |
| BM_006 | Cape Horn; Panama excluded | 9,972.6 | 9,973 | -0.4 | 250 | Within tolerance |
| BM_007 | Suez | 7,943.3 | 7,943 | +0.3 | 250 | Within tolerance |
| BM_008 | Cape of Good Hope; comparison additionally excludes Suez | 7,178.8 | 7,179 | -0.2 | 250 | Within tolerance |

The baseline was generated using the same searoute library. Agreement demonstrates consistency with that model-derived baseline; it does not prove independent accuracy. T13 contains the separate published-reference comparisons and their qualifications.

## 6. Verification performed

The executable evidence records that, for both comparisons:

- Required comparison response fields are present.
- Exactly two options return positive, finite distances.
- Individual route requests reproduce each option's distance and geometry.
- Required and excluded passage **labels** are consistent with the requests.
- The reported difference equals longest minus shortest, and the shortest-option label is correct.
- Repeating the comparison returns the same comparison ID and option distances.
- All four numeric results are within the relevant supplied distance tolerances.

Geometry presence and label consistency are intentionally distinguished from independent geographic compliance. Cape detection is heuristic, and required points are snapped. No independent geometry certification is claimed here. The raw returned geometries, exact requests, route points and warnings are retained for that review.

The separately supplied interface's two corresponding alternative-comparison workflows were also exercised successfully during the combined application review, with the same differences of 6,378.3 and 764.5 nm. That earlier run used the local Member 3 HTTP API. This T20 rerun uses the local engine directly.

## 7. Handoff conclusion

The T20 comparison calculations, reproducibility evidence and write-up are ready for handoff. Member 2's existing comparison functionality supplies the two required alternatives, and Member 1's report explains their constraints, numeric differences and limitations.

Carry the following review items to Members 2 and 3:

1. Review the Cape of Good Hope route geometry against the intended passage because its required waypoint snaps 29.9 nm onto the network.
2. Retain the Tocopilla 114.2 nm snapping warning and the statement that access distances are excluded.
3. Confirm required/excluded passages using geometry/network evidence rather than passage labels alone.
4. If routing behaviour is changed after that review, rerun these comparisons and the affected benchmarks, then update the report.

These are targeted follow-ups. The numerical NGA differences or distance rankings alone do not justify rebuilding the app or tuning the engine to a reference number.

## 8. Evidence and reproduction

- `T20_Verified_Results.json`: full comparison responses, individual requests/responses, geometry, route points, warnings, configuration, run timestamp and source-code hashes.
- `run_t20.py`: a thin runner around Member 2's existing engine. It does not implement a new routing algorithm or modify the supplied files.
- `T20_Comparison_Report.md`: this completed write-up.

From the folder containing this report, using a Python environment with `searoute==1.6.0` and `openpyxl`, run:

```sh
python run_t20.py --member2-folder "/Users/brosman/Downloads/Member2_Routing"
```

The command regenerates the JSON evidence. The written report is a snapshot of the verified results above and should be reviewed if later engine changes produce different results.

Source implementation: Member 2's `voyage_planner/engine.py`, `backend.py`, `config.py` and related files. Service interface: supplied `API_SPECIFICATION.md`, section 7. Benchmark data: supplied updated workbook, BM_005–BM_008. Exact workbook and implementation hashes are recorded in the JSON evidence.
