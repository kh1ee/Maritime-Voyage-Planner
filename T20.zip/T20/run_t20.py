"""Reproduce Member 1's T20 comparisons using Member 2's existing engine.

No routing algorithm, expected-distance adjustment, or source-data change is made.
"""
import argparse
import hashlib
import json
import math
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--member2-folder', required=True, type=Path)
    parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    folder = args.member2_folder.resolve()
    sys.path.insert(0, str(folder))
    from voyage_planner import VoyagePlanner
    planner = VoyagePlanner()
    cases = [
        {'id': 'T20_A', 'name': 'Houston to Tocopilla', 'origin': 'USHOU', 'destination': 'CLTOQ',
         'preset': 'panama_vs_cape_horn', 'benchmarks': ['BM_005','BM_006']},
        {'id': 'T20_B', 'name': 'Rotterdam to Durban', 'origin': 'NLRTM', 'destination': 'ZADUR',
         'preset': 'suez_vs_cape_good_hope', 'benchmarks': ['BM_007','BM_008']},
    ]
    benchmarks = {b.benchmark_id: b for b in planner.data.benchmarks}
    results = []
    for case in cases:
        result = planner.compare_standard_alternatives(case['origin'], case['destination'], case['preset'])
        required_response = {'comparison_id','options','distance_difference_nm','warnings'}
        assert required_response <= result.keys(), 'Missing API specification section 7 comparison fields'
        assert result['status'] == 'success' and len(result['options']) == 2
        responses = []
        for option, benchmark_id in zip(result['options'], case['benchmarks']):
            request = {'origin_port_id': case['origin'], 'destination_port_id': case['destination'],
                       'required_passage': option['required_passage'],
                       'excluded_passage': option['excluded_passage'],
                       'calculation_version': planner.health()['calculation_version']}
            route = planner.route(request)
            assert route['status'] == 'success'
            assert route['distance_nm'] == option['distance_nm']
            assert math.isfinite(route['distance_nm']) and route['distance_nm'] > 0
            assert route['route_geometry']['type'] == 'LineString' and len(route['route_geometry']['coordinates']) >= 2
            assert route['route_geometry'] == option['route_geometry']
            assert option['required_passage'] in route['passages_used']
            excluded = option['excluded_passage']
            excluded = [excluded] if isinstance(excluded,str) else (excluded or [])
            assert all(p not in route['passages_used'] for p in excluded)
            bm = benchmarks[benchmark_id]
            assert bm.origin_id == case['origin'] and bm.destination_id == case['destination']
            baseline_error = round(route['distance_nm']-bm.expected_distance_nm,1)
            responses.append({'benchmark_id': benchmark_id, 'request': request, 'response': route,
                              'supplied_expected_nm': bm.expected_distance_nm,
                              'supplied_tolerance_nm': bm.acceptable_tolerance_nm,
                              'engine_minus_supplied_nm': baseline_error,
                              'within_supplied_distance_tolerance': abs(baseline_error) <= bm.acceptable_tolerance_nm})
        distances = [o['distance_nm'] for o in result['options']]
        difference = round(max(distances)-min(distances),1)
        assert math.isclose(result['distance_difference_nm'],difference,abs_tol=1e-8)
        assert result['shortest_option'] == result['options'][distances.index(min(distances))]['route_name']
        repeated = planner.compare_standard_alternatives(case['origin'],case['destination'],case['preset'])
        assert repeated['comparison_id'] == result['comparison_id']
        assert [o['distance_nm'] for o in repeated['options']] == distances
        results.append({**case, 'comparison_response': result, 'individual_route_evidence': responses,
                        'arithmetic': {'longest_minus_shortest_nm': difference,
                                       'longer_percent_above_shorter': 100*difference/min(distances),
                                       'shorter_percent_below_longer': 100*difference/max(distances)},
                        'checks': {'comparison_response_fields_present': True,
                                   'two_positive_finite_distances': True,
                                   'individual_route_calls_match_options': True,
                                   'geometry_present_and_matches_individual_calls': True,
                                   'required_and_excluded_labels_consistent': True,
                                   'difference_and_shortest_label_correct': True,
                                   'repeat_id_and_distances_deterministic': True},
                        'geometry_compliance_independently_verified': False})
    doc = {'task': 'T20', 'run_time_singapore': datetime.now(ZoneInfo('Asia/Singapore')).isoformat(),
           'role': 'Member 1 comparison and reporting; routing and compare implementation supplied by Member 2',
           'scope': 'Local engine comparison; labels are not independent geographic certification; no hosted API call',
           'engine_root': str(folder), 'engine': planner.backend.engine_info(), 'health': planner.health(),
           'workbook_path': planner.data.source_path, 'workbook_sha256': digest(planner.data.source_path),
           'engine_file_sha256': {str(p.relative_to(folder)):digest(p) for p in sorted((folder/'voyage_planner').glob('*.py'))},
           'comparisons': results,
           'limitations': ['The supplied Excel baseline uses the same searoute library; numerical agreement is not independent accuracy.',
                           'Input points snap to network nodes; input-to-network access distances are excluded.',
                           'Required passages route through snapped reference points; geography requires separate review.',
                           'Cape passage detection is heuristic. Reported passage labels are not independent proof.',
                           'Raw library longitudes can be unwrapped at the date line; geometry is preserved as returned.',
                           'NGA comparisons and their qualifications are recorded separately in T13.']}
    args.output_dir.mkdir(parents=True,exist_ok=True)
    target = args.output_dir/'T20_Verified_Results.json'
    target.write_text(json.dumps(doc,indent=2,allow_nan=False)+'\n')
    for c in results:
        print(c['name'])
        for o in c['comparison_response']['options']:
            print(f"  {o['route_name']}: {o['distance_nm']:,.1f} nm; required {o['required_passage']}; excluded {o['excluded_passage']}")
        print(f"  Difference: {c['arithmetic']['longest_minus_shortest_nm']:,.1f} nm")
        print(f"  Longer above shorter: {c['arithmetic']['longer_percent_above_shorter']:.2f}%")
        print(f"  Shorter below longer: {c['arithmetic']['shorter_percent_below_longer']:.2f}%")
    print('Evidence:',target.resolve())


if __name__ == '__main__':
    main()
