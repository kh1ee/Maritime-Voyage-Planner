# Handoff notes from Member 2 (engine) to the team

Date: 9 Nov 2026 · Engine version 0.1.0 · all 10 benchmarks pass · 78 tests pass

## To Member 3 (architecture, API, independent tests) - T04, T09, T14, T19, T23

**Calling the engine** (one shared instance, e.g. created at startup):

```python
from voyage_planner import VoyagePlanner
planner = VoyagePlanner()
planner.health()                       # GET /health
planner.handle_route(request_dict)     # POST /route   - never raises for client errors
planner.handle_voyage(request_dict)    # POST /voyage
planner.list_ports(); planner.list_passages(); planner.list_positions()   # for dropdowns
```

* `handle_*` return either the success body or the spec error body (`{"status":"error","error_code":...}`).
  Suggested HTTP mapping: `PORT_NOT_FOUND` 404 · `ROUTE_NOT_FOUND` 422 · every other code 400.
* The engine is **thread-safe** (searoute shares global state; the backend serialises calls). Don't bypass `backend.py`.
* Responses are plain JSON-serialisable dicts. `route_id`/`voyage_id` are deterministic hashes of the request.
* Extra fields beyond the spec (all additive): `routing_points`, `distance_by_leg_nm`, `required_passage`,
  `excluded_passage`, `unconstrained_distance_nm`, `network_passages_traversed`, `routing_engine`, `location_type`.
* Per-leg `required_passage` / `excluded_passage` are accepted inside `/voyage` `legs`; `excluded_passage` at voyage level is a default.
* Extras accepted on requests: `origin_position_id`, `waypoints`/`intermediate_stops`, passage lists, port lookup by name/alias/UN-LOCODE.

**Please test independently (T19/T27):** that `passages_used` agrees with the geometry (Suez/Panama from tagged edges,
capes by 50 nm proximity - a heuristic, expect Cape Town false positive); that excluded passages are really absent;
required passages lie on the line; GeoJSON is `[lon, lat]`; line continuity at joins between sub-legs.
Known/intentional behaviours: capes are excluded with a meridian "gate" (test the geometry never crosses it); same-port requests return 0 nm + warning;
an unrecognised `calculation_version` is `INVALID_REQUEST`.

## To Member 4 (UI/maps/exports) - T10, T11, T21, T22, T24

* Draw `route_geometry.coordinates` directly (GeoJSON, `[lon, lat]`). Route lines start/end at the **network node**, not
  the port marker: each entry of `routing_points` gives `requested_*` and `network_*` coordinates and `snap_distance_nm`
  (Tocopilla 114 nm). Suggest a dashed connector + the warning text.
* `planner.list_passages()` returns `can_be_excluded` (now true for all six passages) - every passage can be required or excluded.
* Show `warnings` and `assumptions` from the response; `unconstrained_distance_nm` gives the "+N nm vs normal route" figure for T22.
* Longitudes near the antimeridian can exceed 180 (e.g. 182.8); most map libraries accept this.

## To Member 1 (data, benchmarks, comparison) - T02, T03, T13, T20, T26, T35

1. **T03 conclusion needs revisiting.** `T03_approach_validation.py` routes each approach point to a point 0.01° away; searoute
   snaps both to the same nearest node, so the call can never fail - it passes even for a point hundreds of miles from the
   network. Real result (`results/t16_probe_output.txt`): **Tocopilla 114.2 nm**, Richards Bay 51.0, Callao 32.4, Valparaiso 18.8,
   Buenos Aires 17.2, Shanghai 17.2, Suez 15.2, Hong Kong 14.1 from the nearest node. A meaningful T03 check is this
   snap-distance table. The engine reports it for every request. If you choose different approach points, edit the
   `approach_latitude/longitude` columns in the workbook - the engine uses them automatically.
2. **T02 confirmed**: UNECE list has `GI` + `GIB` → `GIGIB`. The engine keeps `port_id = GIIBZ` (workbook key), reports
   `un_locode = GIGIB`, accepts both. Tell Cargill if the workbook key should change.
3. **T20 comparisons**: call `planner.port_to_port(o, d, required_passage="SUEZ")` and `...="CAPE_GOOD_HOPE"`, or Panama vs
   `required_passage="CAPE_HORN", excluded_passage="PANAMA"`; `distance_nm` of each gives the difference. Note Rotterdam→Durban
   *unconstrained* (7,018 nm) already goes round the Cape; BM_007 (via Suez, 7,943) is **longer** than BM_008 (via Cape, 7,179).
4. **Validation write-up facts**: the baseline reproduces to ≤0.4 nm because it came from the same library; record
   searoute 1.6.0, `append_orig_dest=False`, default restriction `northwest`, the coordinates in `benchmark_results.json`.
   BM_009 start is 124 nm from the network.
5. Benchmarks use blank-as-space cells (`" "`); the loader treats them as "no constraint".

## Tracker note

Tracker still shows every task "Not Started" although T02/T03 results exist. Updated copy for Member 2's rows is in
`Voyage_Planner_Task_Tracker_4_Members_updated.xlsx`. T05-T08 and T16 were due 25 Oct-7 Nov (delivered late);
T17 (due 12 Nov) and T18 (due 14 Nov) are delivered early. T01/T04 (prerequisites, Member 3) were not available, so the engine was built
directly to `API_SPECIFICATION.md`.

## Commands to run 
Create Virtual Environment > Install Packages > Run benchmarks
cd C:\Users\User\Downloads\Member2_Routing_wcapeexclusion\Member2_Routing
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt

.\.venv\Scripts\python.exe scripts\run_benchmarks.py
.\.venv\Scripts\python.exe scripts\demo.py
.\.venv\Scripts\python.exe -m pytest -q