# T32 - Routing methodology (draft v1 for review by Members 1 and 3)

Owner: Member 2 · Applies to: calculation_version **0.1.0**, searoute-py **1.6.0**, Python 3.9+.

## 1. Purpose and scope

The engine returns the maritime distance, route geometry, passages used, assumptions and warnings for:
port → port, vessel position → port, and multi-leg itineraries, optionally constrained to **require** or **exclude**
canals/straits/capes. It covers the 29 supplied ports, 6 passage reference points and 6 synthetic positions, and
returns results in the format of `API_SPECIFICATION.md`. It is an academic prototype, not for navigation.

## 2. Pipeline (one request)

```
request (dict)
  1  validate                      version, types, ids, coordinate ranges, passages          -> typed error or continue
  2  resolve locations             port (id / UN/LOCODE / name / alias), position id, or coordinates
  3  plan the leg                  [origin] + [required passages, ordered] or [user waypoints] + [destination]
  4  route each segment            searoute shortest path, excluded passages blocked           (cached, locked)
  5  check                         path exists? no excluded tag crossed? snap distances?
  6  aggregate                     segment distances rounded to 0.1 nm and summed; polylines joined
  7  describe                      passages_used, routing_points, assumptions, warnings, versions, deterministic id
```

## 3. Algorithms and rules

**Shortest path.** searoute runs bidirectional Dijkstra on its 9,708-node ocean graph (edge weight = great-circle km,
converted to nautical miles). The engine does not alter the graph.

**Coordinates.** Everything is `[longitude, latitude]` when talking to searoute and in GeoJSON; the API objects use
`{"latitude", "longitude"}`. Ports are routed from their **approach point** (`approach_latitude/longitude`, currently
equal to the port coordinates), but displayed with their port coordinates.

**Snapping.** searoute moves each endpoint to the nearest graph node. The engine measures that gap and reports it; the gap
is not added to the distance (see §6).

**Required passage (T18).** A required passage is a mandatory intermediate point: distance = d(origin→passage point) +
d(passage point→destination). With several required passages (max 4) all orders are tried and the **shortest total** is
kept (ties keep the user's order). Required passages are always listed in `passages_used`.

**Excluded passage (T17).** All six passages can be excluded, by two mechanisms:
* *Canals / straits with tagged edges* (PANAMA, SUEZ, GIBRALTAR, MALACCA): the tag is added to the router's restriction
  list, so those edges cost infinity.
* *Capes* (CAPE_HORN, CAPE_GOOD_HOPE) have no tagged edges, so a **gate** is used: the meridian of the cape's reference
  point from that point south to the pole. In a private copy of the network every edge crossing the gate is relabelled
  and blocked, so no route can round the cape. Magellan / Beagle stay open for Cape Horn. If no cape is excluded the
  original network is used unchanged.

A passage that is both required and excluded is `INVALID_REQUEST`. After every route the engine verifies that no excluded
tag was crossed and the geometry does not cross an excluded gate. An excluded passage is never listed in `passages_used`.

**Multi-leg (T08).** Each leg is routed independently (and may carry its own required/excluded passages);
`total_distance_nm` = sum of the leg distances. A voyage-level `excluded_passage` is a default for all legs.
Waypoints inside one `/route` call are visited in the order given and cannot be combined with `required_passage`
(use `/voyage` legs instead).

**Rounding.** Each segment is rounded to 0.1 nm, a leg is the sum of its rounded segments, a voyage is the sum of its
rounded legs, so displayed numbers always add up exactly.

**passages_used.** Canals/straits (Panama, Suez, Gibraltar, Malacca) come from the tagged edges the path crossed -
exact. Capes have no edges, so a cape counts as used when the path passes within **50 nm** of its reference point -
a heuristic (known false positive: any route ending at Cape Town, 27 nm from the Cape of Good Hope point).

**Determinism.** Same request + same data + same library version ⇒ identical response, including `route_id` /
`voyage_id` (a hash of the normalised request). Results are cached per (origin, destination, restrictions).

## 4. Inputs accepted (superset of the specification)

| Field | Form | Notes |
|---|---|---|
| `origin_port_id`, `destination_port_id` | port id, UN/LOCODE, name or alias | case-insensitive |
| `origin_coordinates`, `destination_coordinates` | `{"latitude": n, "longitude": n}` | −90..90, −180..180 |
| `origin_position_id` | `POS_001`… | extension: synthetic positions by id |
| `required_passage`, `excluded_passage` | id, or list of ids; `null`/`""`/`" "` = none | case-insensitive |
| `waypoints` / `intermediate_stops` | list of port / passage / position ids or coordinate objects | |
| `legs` (voyage) | list of route-like objects | per-leg passage fields allowed |
| `calculation_version` | must be `"0.1.0"` if given | otherwise `INVALID_REQUEST` |

## 5. Outputs and error codes

Success responses follow spec §5/§6, plus extra fields: `routing_points` (what was routed, with snapped node and
snap distance), `distance_by_leg_nm`, `required_passage`, `excluded_passage`, `unconstrained_distance_nm`,
`network_passages_traversed`, `routing_engine` (library name/version/network size/config).

| Code | When |
|---|---|
| `PORT_NOT_FOUND` | unknown origin/destination/waypoint |
| `INVALID_COORDINATES` | not an object, missing key, non-number/NaN/bool, out of range |
| `MISSING_ORIGIN` / `MISSING_DESTINATION` | location absent |
| `INVALID_PASSAGE` | unknown passage id |
| `ROUTE_NOT_FOUND` | restrictions leave no path (searoute would return 0 nm silently) |
| `INVALID_REQUEST` | wrong types, id **and** coordinates both given, required = excluded, unsupported version, unknown position id, waypoints + required, empty legs |

## 6. Assumptions and limitations (state these in the report)

1. **Circular baseline.** Benchmarks were produced by searoute-py 1.6.0; passing shows consistency, not accuracy.
   Spot-check with NGA Pub. 151 (Member 1, T13/T26).
2. **Snapping gap not counted.** Tocopilla 114 nm, Richards Bay 51 nm, Callao 32 nm, POS_001 124 nm from the nearest
   node. The engine warns; the numbers match the baseline because the baseline ignores the gap too.
3. **Coarse network.** Ocean edges are straight great-circle chords between nodes; narrow channels and port approaches
   are generalised. Rotterdam–Hamburg 298 nm should be compared with Pub. 151 (T13).
4. **Cape handling.** Cape exclusion is a model (a meridian gate), not a navigational rule: a port on the far side of a
   cape is reached the long way round (Cape Town→Durban excluding the Cape of Good Hope = 11,794 nm via Suez).
   `passages_used` for capes is proximity-based (50 nm). The first request using a cape exclusion takes ~0.2 s extra to build the gated network copy.
5. **Passage points are waypoints, not transit models.** No canal transit times, tolls, draft/beam limits, piracy or
   weather. Requiring an unrelated passage (e.g. Panama for Singapore→Hong Kong) is allowed and just gives a long route;
   a warning appears when the constrained route is >50% longer.
6. **Order of several required passages** is chosen automatically (shortest total), not by real-world convention.
7. **One engine, one network.** No bunkering/ETA/speed logic (duration is not exposed).
8. **Gibraltar UN/LOCODE** corrected to GIGIB (T02); `port_id` stays `GIIBZ`.

## 7. Validation summary (10 Cargill benchmarks, `results/benchmark_results.md`)

All 10 pass; the largest deviation from the supplied value is 0.4 nm (tolerances 100-300 nm). BM_009 is a functional
test only. Reproduce with `python3 scripts/run_benchmarks.py`. Independent test suite for these functions: `python3 -m pytest`
(78 tests). Member 3 owns the independent passage/geometry tests (T19, T27).

## 8. Reproducibility record

searoute-py 1.6.0 · network 9,708 nodes / 15,970 edges · units nm · default restriction `northwest` ·
`append_orig_dest=False` · workbook `voyage_planner_datasets.xlsx` (27 Oct 2026 copy, identical in both zips) ·
passage points = coordinates in the Passage Reference tab · port points = Port Reference approach coordinates.
